#include <stdio.h>
int main(){
    int id;
printf("Digite sua idade ");
scanf("%i", &id);
if(id<=12){
printf ("você é criança");
}else if (id<=17){
    printf ("Você é adolescente");
}else if (id<=59){
    printf("Você é adulto");
}else{
    printf("você é idoso");
}


}
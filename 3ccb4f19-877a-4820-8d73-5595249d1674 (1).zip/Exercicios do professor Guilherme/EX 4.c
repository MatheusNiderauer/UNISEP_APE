#include <stdio.h>
int main(){
int n1;
printf("Digite sua nota ");
scanf("%i", &n1);
 if(n1 <= 5){
  printf("REPROVADO");
 }else if(n1 <= 6.9){
  printf("RECUPERAÇÃO");
 }else{
  printf("APROVADO");
 }
 
}
#include <stdio.h>
int main(){
int ano;
printf("digite o ano ");
scanf("%i", &ano);
if(ano%4==0){
    printf("Ano %i é bissexto",ano);
}else
printf("Ano %i não é bissexto", ano);
}




#include <stdio.h>
int main(){
int vl;
printf("digite o valor da compra: ");
scanf("%i", &vl);
if(vl>100){
    printf("Valor a ser cobrado %i", vl-(vl/10));
}else
printf("valor a ser cobrado %i", vl-(vl/20));
}




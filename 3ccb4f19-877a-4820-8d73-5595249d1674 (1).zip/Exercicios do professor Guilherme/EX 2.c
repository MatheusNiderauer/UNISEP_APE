#include <stdio.h>
int main(){
    int num;
    printf("digite um número");
    scanf("%i", &num);
    if(num %2==0){
        printf("É par");
    }else{
        printf("è impar");
    }
    }
#include <stdio.h>
int main(){
int n1, n2; 
printf("digite seu número ");
scanf("%i", &n1 );
printf ("digite seu segundo número ");
scanf("%i", &n2);
if(n1<n2){
    printf("O número:%i é o maior número", n2);
}else if(n1>n2){
    printf("O número:%i é o maior número", n1);
}else{
printf("Os números são iguais");
}
}


